package com.example.shopapothek.view;

import lombok.Data;

import java.time.LocalDate;
@Data
public class RepositoryResponseView {
    private String language;
    private String Content;
    private LocalDate createdOn;

    private RepositoryResponseView(Builder builder) {
        setLanguage(builder.language);
        setContent(builder.Content);
        setCreatedOn(builder.createdOn);
    }


    public static final class Builder {
        private String language;
        private String Content;
        private LocalDate createdOn;

        public Builder() {
        }

        public Builder withLanguage(String val) {
            language = val;
            return this;
        }

        public Builder withContent(String val) {
            Content = val;
            return this;
        }

        public Builder withCreatedOn(LocalDate val) {
            createdOn = val;
            return this;
        }

        public RepositoryResponseView build() {
            return new RepositoryResponseView(this);
        }
    }
}
