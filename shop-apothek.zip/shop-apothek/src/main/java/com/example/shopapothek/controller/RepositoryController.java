package com.example.shopapothek.controller;

import com.example.shopapothek.entity.RepositoryEntity;
import com.example.shopapothek.service.RepositoryService;
import com.example.shopapothek.utils.RepositoryFilter;
import com.example.shopapothek.view.RepositoryResponseListView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping(value = "/admin",
        produces = MediaType.APPLICATION_JSON_VALUE)
public class RepositoryController  {

    @Autowired
    private RepositoryService repositoryService;

    @RequestMapping(value = "/repositories/{pageIndex}/{pageSize}", method = RequestMethod.GET)
    public ResponseEntity<RepositoryResponseListView>  getRepositories(@RequestParam(name = "filter.dateFrom", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dateFrom,
                                      @RequestParam(value = "filter.language", required = false) String language,
                                      @RequestParam(value = "pageIndex", required = false, defaultValue = "") Integer pageIndex,
                                      @RequestParam(value = "pageSize", required = false, defaultValue = "") Integer pageSize) {

        Pageable pageable = PageRequest.of(pageIndex, pageSize);

        RepositoryFilter filter = new RepositoryFilter.Builder()
                .withFromDate(dateFrom)
                .withLanguage(language)
                .build();

        RepositoryResponseListView response = repositoryService.getRepositories(filter, pageable);

        return ResponseEntity.ok(response);
    }


}