package com.example.shopapothek.view;

import lombok.Data;

import java.util.List;

@Data
public class RepositoryResponseListView {
    List<RepositoryResponseView> responseList;

    private RepositoryResponseListView(Builder builder) {
        setResponseList(builder.responseList);
    }

    public static final class Builder {
        private List<RepositoryResponseView> responseList;

        public Builder() {
        }

        public Builder withResponseList(List<RepositoryResponseView> val) {
            responseList = val;
            return this;
        }

        public RepositoryResponseListView build() {
            return new RepositoryResponseListView(this);
        }
    }
}
