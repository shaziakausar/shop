package com.example.shopapothek.Repository;

import com.example.shopapothek.entity.RepositoryEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.lang.Nullable;

import java.awt.print.Pageable;

public interface GitRepository extends JpaRepository<RepositoryEntity, Long>, JpaSpecificationExecutor<RepositoryEntity> {

    Page<RepositoryEntity> findAllBy(@Nullable Specification<RepositoryEntity> spec, Pageable pageable);
}
