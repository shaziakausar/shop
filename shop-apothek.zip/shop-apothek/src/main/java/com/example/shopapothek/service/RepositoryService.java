package com.example.shopapothek.service;

import com.example.shopapothek.utils.RepositoryFilter;
import com.example.shopapothek.view.RepositoryResponseListView;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;

public interface RepositoryService {
    RepositoryResponseListView getRepositories(RepositoryFilter filter, Pageable pageable);
}
