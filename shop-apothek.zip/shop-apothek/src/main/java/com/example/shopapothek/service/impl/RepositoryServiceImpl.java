package com.example.shopapothek.service.impl;

import com.example.shopapothek.Repository.GitRepository;
import com.example.shopapothek.entity.RepositoryEntity;
import com.example.shopapothek.service.RepositoryService;
import com.example.shopapothek.specifications.RepositorySpecifications;
import com.example.shopapothek.utils.RepositoryFilter;
import com.example.shopapothek.view.RepositoryResponseListView;
import com.example.shopapothek.view.RepositoryResponseView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.*;

import java.util.stream.Collectors;

@Service("repositoryService")
public class RepositoryServiceImpl implements RepositoryService {

    @Autowired
    private GitRepository gitRepository;

    //        This is the implementation based on fact that using public Url we have dumped response in our database and quering our DB to return response
    @Override
    public RepositoryResponseListView  getRepositories(RepositoryFilter filter, Pageable pageable) {
        Specification<RepositoryEntity> filterSpecification = RepositorySpecifications.getSpecification(filter);

        Page<RepositoryEntity> repositories = gitRepository.findAll(filterSpecification, pageable);
        return map(repositories);
    }

    private RepositoryResponseListView map(Page<RepositoryEntity> repositories){

        return new RepositoryResponseListView.Builder()
                .withResponseList(repositories.getContent().stream().map(r -> map(r)).collect(Collectors.toList()))
                .build();

    }

    public RepositoryResponseView map(RepositoryEntity repository) {
        RepositoryResponseView repositoryView = new RepositoryResponseView.Builder()
                .withContent(repository.getContent())
                .withLanguage(repository.getLanguage())
                .withCreatedOn(repository.getDate())
                .build();

        return repositoryView;
    }

}
