package com.example.shopapothek.entity;

import jdk.jfr.Enabled;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name ="repository")
@Data
public class RepositoryEntity {


    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
    )
    private Long id;

    @Column(name = "content", nullable = false)
    private String content;

    @Column(name="created_at")
    private LocalDate date;

    @Column(name = "language")
    private String language;
}
