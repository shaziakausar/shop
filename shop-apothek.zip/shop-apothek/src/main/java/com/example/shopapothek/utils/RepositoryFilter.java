package com.example.shopapothek.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RepositoryFilter {

    private String language;
    private LocalDate fromDate;

    private RepositoryFilter(Builder builder) {
        setLanguage(builder.language);
        setFromDate(builder.fromDate);
    }

    public static final class Builder {
        private String language;
        private LocalDate fromDate;

        public Builder() {
        }

        public Builder withLanguage(String val) {
            language = val;
            return this;
        }

        public Builder withFromDate(LocalDate val) {
            fromDate = val;
            return this;
        }

        public RepositoryFilter build() {
            return new RepositoryFilter(this);
        }
    }
}
