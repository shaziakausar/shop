package com.example.shopapothek.specifications;

import com.example.shopapothek.entity.RepositoryEntity;
import com.example.shopapothek.utils.RepositoryFilter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;

public final class RepositorySpecifications {


    public static Specification<RepositoryEntity> getSpecification(RepositoryFilter repositoryFilter) {
        return (root, query, cb) -> {

            final Collection<Predicate> predicates = new ArrayList<>();


            createRepositoryFiltersPredicates(repositoryFilter, root, cb, predicates);

            return cb.and(predicates.toArray(new Predicate[predicates.size()]));

        };
    }

    private static void createRepositoryFiltersPredicates(RepositoryFilter repositoryFilter, Root<RepositoryEntity> root, CriteriaBuilder cb, Collection<Predicate> predicates) {

        Predicate fromPredicate = repositoryCreationBetween(repositoryFilter.getFromDate(), cb, root);
        if (fromPredicate != null) {
            predicates.add(fromPredicate);
        }

        Predicate languagePredicate = languagePredicate(repositoryFilter.getLanguage(), cb, root);
        if (languagePredicate != null) {
            predicates.add(languagePredicate);
        }
    }

    private static Predicate repositoryCreationBetween(LocalDate from, CriteriaBuilder cb, Root root) {
        if (from != null) {
            return cb.between(root.get("dateFrom").as(LocalDate.class), from, LocalDate.now());
        } else {
            return null;
        }
    }

    private static Predicate languagePredicate(String lang, CriteriaBuilder cb, Root root) {
        if (!StringUtils.isEmpty(lang)) {
            return cb.equal(root.get("language"), lang);
        } else {
            return null;
        }
    }
}


