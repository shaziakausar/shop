package com.example.shopapothek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopApothekApplicationTests {

    @Test
    void contextLoads() {
    }

}
